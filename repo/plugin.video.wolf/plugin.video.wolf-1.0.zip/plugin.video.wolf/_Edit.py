import xbmcaddon

MainBase = 'https://pastebin.com/raw/f7W92z88'
addon = xbmcaddon.Addon('plugin.video.wolf')